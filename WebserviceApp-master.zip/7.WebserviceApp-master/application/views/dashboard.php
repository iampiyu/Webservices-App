<?php include('partials/header.php'); ?>
	<div class="row">
		<div class="text-center col-md-10 col-lg-10 col-md-offset-1 col-lg-offset-1" id="card" style="padding: 10px; margin-bottom: 5px;">
			<h3>Welcome to Webservice App</h3>
			<h4>: Steps :</h4>
			<h4>In this tutorial we are going to learn how to setup and use webservices into CodeIgniter app.</h4>
		</div> 

		<div class="col-md-10 col-lg-10 col-md-offset-1 col-lg-offset-1" id="card" style="padding: 10px; margin-bottom: 5px;">
			<strong>1.</strong>
			<h4> <p>There is two ways where you can download CodeIgniter Webservice zip</p>
			 <p> i) Go to ( https://github.com/chriskacerguis/codeigniter-restserver ) download zip follow there instructions.</p>
			<p>ii) Or you can directly download from this linke ( ............ ) where I have alery setup all stuff for you.</p>
			</h4>
		</div> 

		<div class="col-md-10 col-lg-10 col-md-offset-1 col-lg-offset-1" id="card" style="padding: 10px; margin-bottom: 5px;">
			<strong>2.</strong>
			<h4>
			<p>Open <strong>application folder => config folder</strong> here you will find <strong>rest.php</strong> newally added.</p>
			<p>Open <strong>application folder => languge folder => english folder</strong> you will find <strong> rest_controller_lang.php</strong> newally added.</p>	
			<p>Open <strong>application folder => library folder </strong> you will find <strong> format.php and rest_controller.php</strong> newally added.</p>		
			 				 
			</h4>
		</div> 



	</div>
 
<?php include('partials/footer.php'); ?>